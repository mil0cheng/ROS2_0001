import serial
import struct
import threading
import time
import sys

class RobotSerialController:
    def __init__(self, port, baudrate=115200):
        try:
            self.ser = serial.Serial(port, baudrate, timeout=0.1)
            print(f"成功连接到串口: {port}，波特率: {baudrate}")
        except Exception as e:
            print(f"串口打开失败: {e}")
            sys.exit(1)
            

        self.is_running = True
        self.rx_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.rx_thread.start()


    def send_led_switch(self, action):

        header1 = 0x5A
        header2 = 0xA5
        cmd = 0x01
        
        checksum = (header1 + header2 + cmd + action) % 256
        
        frame = bytes([header1, header2, cmd, action, checksum])
        self.ser.write(frame)
        print(f"[发送] 开关指令 -> Hex: {frame.hex(' ').upper()}")

    def send_led_brightness(self, brightness_val):

        header1 = 0x5A
        header2 = 0xA5
        cmd = 0x02
        
        brightness_val = max(0.0, min(1.0, float(brightness_val)))
        
        float_bytes = struct.pack('<f', brightness_val)
        
        checksum = (header1 + header2 + cmd + sum(float_bytes)) % 256
        

        frame = bytes([header1, header2, cmd]) + float_bytes + bytes([checksum])
        self.ser.write(frame)
        print(f"【发送】 亮度指令 ({brightness_val}) -> Hex: {frame.hex(' ').upper()}")


    def _receive_loop(self):

        state = 0
        calc_sum = 0
        gpio_state = 0
        
        while self.is_running:
            if self.ser.in_waiting > 0:

                byte = self.ser.read(1)[0]
                
                if state == 0:   # WAIT_HEADER_1
                    if byte == 0x5A:
                        state = 1
                        calc_sum = byte
                        
                elif state == 1: # WAIT_HEADER_2
                    if byte == 0xA5:
                        state = 2
                        calc_sum += byte
                    elif byte == 0x5A:

                        state = 1
                        calc_sum = byte
                    else:
                        state = 0
                        
                elif state == 2: 
                    gpio_state = byte
                    calc_sum += byte
                    state = 3
                    
                elif state == 3: # WAIT_CHECKSUM

                    if byte == (calc_sum % 256):

                        status_str = "高电平 (1)" if gpio_state == 0x01 else "低电平 (0)"

                        print(f"\r【接收】硬件状态更新: 目标GPIO为 {status_str}       ", end="", flush=True)
                    else:

                        pass 
                    
                    state = 0

    def close(self):
        self.is_running = False
        self.ser.close()
        print("\n串口已安全关闭。")

if __name__ == '__main__':

    PORT_NAME = 'COM11' 
    
    controller = RobotSerialController(port=PORT_NAME, baudrate=115200)
    
    print("\n" + "="*40)
    print("上位机控制台")
    print("输入 'on'   : 开灯")
    print("输入 'off'  : 关灯")
    print("输入 'tog'  : 反转灯光状态")
    print("输入 'b 0.5': 设置亮度 (0.0 到 1.0 之间)")
    print("输入 'q'    : 退出程序")
    print("="*40 + "\n")

    try:
        while True:

            user_input = input("\n请输入指令 >>> ").strip().lower()
            
            if user_input == 'on':
                controller.send_led_switch(0x01)
            elif user_input == 'off':
                controller.send_led_switch(0x00)
            elif user_input == 'tog':
                controller.send_led_switch(0x02)
            elif user_input.startswith('b '):
                try:
                    val = float(user_input.split(' ')[1])
                    controller.send_led_brightness(val)
                except ValueError:
                    print("亮度值格式错误，请输入如: b 0.5")
            elif user_input == 'q':
                break
            else:
                print("未知指令，请重新输入。")
                
            time.sleep(0.1) 
            
    except KeyboardInterrupt:
        pass
    finally:
        controller.close()