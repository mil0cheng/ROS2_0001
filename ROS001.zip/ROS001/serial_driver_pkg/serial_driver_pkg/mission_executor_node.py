import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Float32
import json
import os

class MissionExecutorNode(Node):
    def __init__(self):
        # 1. 严格按照要求命名的节点：mission_executor_node
        super().__init__('mission_executor_node')
        
        # 创建发布者
        self.pub_switch = self.create_publisher(Int8, '/cmd_led_switch', 10)
        self.pub_bright = self.create_publisher(Float32, '/cmd_led_brightness', 10)
        
        # 2. 严格按照要求读取：mission.json
        file_path = os.path.expanduser('~/mission.json')
        
        try:
            with open(file_path, 'r') as f:
                self.script = json.load(f)
                self.script.sort(key=lambda x: x['time']) # 按时间排序
        except FileNotFoundError:
            self.get_logger().error(f"找不到文件：{file_path}！")
            return
            
        self.start_time = self.get_clock().now()
        self.current_idx = 0
        self.timer = self.create_timer(0.1, self.timer_cb) # 10Hz 检查一次时间
        self.get_logger().info("已启动")

    def timer_cb(self):
        # 跑完一次就自动停止的逻辑（去掉了无限循环）
        if self.current_idx >= len(self.script):
            self.get_logger().info("执行完毕")
            self.timer.cancel()  # 关键：跑完就取消定时器，不再循环
            return

        now = self.get_clock().now()
        elapsed = (now - self.start_time).nanoseconds / 1e9 # 转换为秒
        
        target = self.script[self.current_idx]
        if elapsed >= target['time']:
            if target['type'] == 'switch':
                msg = Int8(data=int(target['value']))
                self.pub_switch.publish(msg)
            elif target['type'] == 'brightness':
                msg = Float32(data=float(target['value']))
                self.pub_bright.publish(msg)
            
            self.get_logger().info(f"时间到({elapsed:.1f}s): 执行 {target['type']} -> {target['value']}")
            self.current_idx += 1

def main():
    rclpy.init()
    try:
        rclpy.spin(MissionExecutorNode())
    except KeyboardInterrupt:
        pass
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()
