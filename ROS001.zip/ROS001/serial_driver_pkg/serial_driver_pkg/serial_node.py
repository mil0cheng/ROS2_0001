import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8, Bool, Float32  # 【注意】这里加上了 Float32
import serial
import struct

class SerialDriverNode(Node):
    def __init__(self):
        super().__init__('serial_driver')
        
        self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=0.05)
        self.get_logger().info(" 成功连接 /dev/ttyUSB0")
        
        self.gpio_pub = self.create_publisher(Bool, '/gpio_state', 10)
        self.sub_switch = self.create_subscription(Int8, '/cmd_led_switch', self.switch_cb, 10)
        
        # 【加回来的代码】订阅亮度话题
        self.sub_bright = self.create_subscription(Float32, '/cmd_led_brightness', self.bright_cb, 10)
        
        self.timer = self.create_timer(0.01, self.read_cb)
        self.state = 0
        self.calc_sum = 0
        self.gpio_val = 0

    def switch_cb(self, msg):
        h1, h2, cmd, act = 0x5A, 0xA5, 0x01, msg.data
        chk = (h1 + h2 + cmd + act) % 256
        self.ser.write(bytes([h1, h2, cmd, act, chk]))
        self.get_logger().info(f"[下发] 开关指令: {act}")

    # 【加回来的代码】处理亮度的回调函数，包含 float 到小端序的转换
    def bright_cb(self, msg):
        val = max(0.0, min(1.0, float(msg.data)))
        h1, h2, cmd = 0x5A, 0xA5, 0x02
        float_bytes = struct.pack('<f', val)
        chk = (h1 + h2 + cmd + sum(float_bytes)) % 256
        self.ser.write(bytes([h1, h2, cmd]) + float_bytes + bytes([chk]))
        self.get_logger().info(f"[下发] 亮度指令: {val:.2f}")

    def read_cb(self):
        while self.ser.in_waiting > 0:
            byte = self.ser.read(1)[0]
            if self.state == 0:
                if byte == 0x5A: 
                    self.state = 1
                    self.calc_sum = byte
            elif self.state == 1:
                if byte == 0xA5: 
                    self.state = 2
                    self.calc_sum += byte
                else: 
                    self.state = 0
            elif self.state == 2:
                self.gpio_val = byte
                self.calc_sum += byte
                self.state = 3
            elif self.state == 3:
                if byte == (self.calc_sum % 256):
                    msg = Bool()
                    msg.data = (self.gpio_val == 0x01)
                    self.gpio_pub.publish(msg)
                self.state = 0

def main():
    rclpy.init()
    try:
        rclpy.spin(SerialDriverNode())
    except KeyboardInterrupt:
        pass
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()
